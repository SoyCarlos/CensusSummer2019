#pip install tabula-py
#pip install pypdf2
#pip install python-docx
import tabula
import PyPDF2
import pandas as pd
from collections import Counter
import sys
import numpy as np
import os
from docx.api import Document


def pdf(file):
    """Takes in PDF file path and converts it to pandas DataFrame.
    
    Arguments:
        file {String} -- PDF file path
    
    Returns:
        pandas DataFrame -- Table extracted from PDF
    """
    frame = tabula.read_pdf(file, pages='all', output_format='csv', guess=False)
    frame.drop_duplicates(keep=False, inplace=True)

    filename = file.split(".")[-2].split("\\")[-1]
    my_path = os.path.abspath(os.path.dirname(__file__))
    combine = "/export/" + filename + "_parsed.csv"
    path = my_path + combine 
    return frame.to_csv(path, index=None)


def one_cell(row):
    vals = set()
    for cell in row.cells:
        vals.add(cell.text)
    if len(row.cells) != len(vals):
        return True
    elif len(vals) == 1 and (vals[0] == "" or vals[0] == " "):
        return True
    else: 
        return False


def empty_rows(row):
    vals = set()
    for cell in row.cells:
        vals.add(cell.text)
    if len(vals) == 1 and (list(vals)[0] == "" or list(vals)[0] == " "):
        return True
    else: 
        return False


def get_word_table(table):
    data = []
    keys = None
    find_columns = True
    for i, row in enumerate(table.rows):
        text = (cell.text for cell in row.cells)
        if find_columns:
            print("Looking for columns")
            keys = tuple(text)
            if one_cell(row):
                continue
            find_columns=False
            continue
        if empty_rows(row):
            continue
        row_data = dict(zip(keys, text))
        data.append(row_data)

    df = pd.DataFrame(data)
    return df

def word(file):
    document = Document(file)
    dfs = []
    for table in document.tables:
        dfs.append(get_word_table(table))

    filename = file.split(".")[-2].split("\\")[-1]
    my_path = os.path.abspath(os.path.dirname(__file__))
 
    for i, df in enumerate(dfs):
        print(df)
        combine = "/export/" + filename + "_parsed_" + str(i) + ".csv"
        path = my_path + combine
        df.to_csv(path, index=None)
    


def excel(file):
    pass


def get_file_type(file):
    """
    Takes in file path and returns file extension.
    :param file: File Path (String)
    :return: File Extension (String)
    """
    file_type = file.split(".")[-1]
    print("You provided a " + file_type + " file.")
    return file_type


def parser(file):
    options = {
        'csv': excel,
        'pdf': pdf,
        'xlsx': excel,
        'doc': word,
        'docx': word
    }
    file_type = get_file_type(file)
    print(file)

    if file_type not in options.keys():
        print("File type " + file_type + " not supported.")
        return None
    
    return options[file_type](file)


parser(sys.argv[1])
# TODO USE METHODS LEARNED IN ADDRESS AND PHONE PARSING FOR WEB CRAWLER. FIND THOSE PARTS IN TEXT FOR TABLES LIKE CPAP EXTRACT TEXT AND REMAINING TEXT SHOULD JUST BE FACILITY NAME?